package com.company;

/**
 * Created by dbaker on 2/15/2019.
 */
public class Gradebook {
    //properties
    //list/array of sections
    int currentSection;


    //methods
    //changeSection(string sectionName); sets the currently active section
    //boolean addSection(String sectionName)//creates a new section if there are not already 6 sections and sectionName isnt already used

}
