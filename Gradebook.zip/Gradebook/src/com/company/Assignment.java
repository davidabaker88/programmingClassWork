package com.company;

/**
 * Created by dbaker on 2/15/2019.
 */
public class Assignment {
    int pointsPossible;
    int pointsEarned;
    String assignmentName;

}
