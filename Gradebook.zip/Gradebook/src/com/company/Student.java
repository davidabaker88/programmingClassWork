package com.company;

/**
 * Created by dbaker on 2/15/2019.
 */
public class Student {
    String firstName;
    String lastName;
    String username;
    long phoneNumber;
    //list of Assignments
    int daysAbsent;
    int daysTardy;


}
